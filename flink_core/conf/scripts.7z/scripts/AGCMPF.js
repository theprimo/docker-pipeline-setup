{
        
    rels: {
        
        "AGCMPF_ProductOption": {
            "to": "ProductOption",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider == "00")
                    return "LA::Pru::ProductOption::" + input.chdrnum + "::" + input.life + "::" + input.coverage;
                return null;
            }
        },
        
        "AGCMPF_ProductComponentOption": {
            "to": "ProductComponentOption",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider && input.rider != "00")
                    return "LA::Pru::ProductComponentOption::" + input.chdrnum + "::" + input.life + "::" + input.coverage + "::" + input.rider;
                return null;
            }
        }
    }
}

