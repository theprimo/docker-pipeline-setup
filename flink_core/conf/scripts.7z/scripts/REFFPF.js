{
        
    rels: {
        "REFFPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Policy::" + input.chdrnum;
                return null;
            }
            
        }
    }
}

