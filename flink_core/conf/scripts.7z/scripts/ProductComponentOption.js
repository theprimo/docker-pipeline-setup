{
	
	targets: {
		
		"ProductComponentOption_Target" : {
			type: "ProductComponentOption"
		}
	},
	
	rels: {
		
		"COVRPF_ProductComponentOption" : {
			"to": "LifeAsia.COVRPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"ProductComponentOption_Policy" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.chdrnum) {
					return "LA::Pru::Policy::" + input.chdrnum;
				}
				return null;
			}
		},
		
		"ProductComponentOption_ProductOption" : {
			"to": "ProductOption",
			"cardinality": "one",
			"direction": "out",
			//"field": "productOption",
			"id": function(input, state) {
				if (input && input.chdrnum && input.life && input.coverage)
				return "LA::Pru::ProductOption::" + input.chdrnum + "_" + input.life + "_" + input.coverage;
				return null;
			}
		},
		
		"AGCMPF_ProductComponentOption" : {
			"to": "LifeAsia.AGCMPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"LEXTPF_ProductComponentOption" : {
			"to": "LifeAsia.LEXTPF",
			"cardinality": "one",
			"direction": "in"
		},
		"INCIPF_ProductComponentOption" : {
			"to": "LifeAsia.INCIPF",
			"cardinality": "one",
			"direction": "in"
		}
	}
}