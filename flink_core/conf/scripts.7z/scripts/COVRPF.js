{
        
    rels: {
        "CHDRPF_COVRPF" : {
            "to": "LifeAsia.CHDRPF",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.chdrnum)
                    return "CHDRPF::" + input.chdrnum;
                return null;
            }
        },
        "COVRPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Policy::" + input.chdrnum;
                return null;
            }
        },

        "COVRPF_Policy_Many": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Policy::" + input.chdrnum;
                return null;
            }
        },
        
        "COVRPF_ProductOption": {
            "to": "ProductOption",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider == "00")
                    return "LA::Pru::ProductOption::" + input.chdrnum + "_" + input.life + "_" + input.coverage;
                return null;
            }
            
        },

        "COVRPF_ProductOption_Many": {
            "to": "ProductOption",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider != "00")
                    return "LA::Pru::ProductOption::" + input.chdrnum + "_" + input.life + "_" + input.coverage;
                return null;
            }            
        },
        
        "COVRPF_ProductComponentOption": {
            "to": "ProductComponentOption",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider && input.rider != "00")
                    return "LA::Pru::ProductComponentOption::" + input.chdrnum + "_" + input.life + "_" + input.coverage + "_" + input.rider;
                return null;
            }
            
        },
        "COVRPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Proposal::" + input.chdrnum;
                return null;
            }
        },
        
    }
}

