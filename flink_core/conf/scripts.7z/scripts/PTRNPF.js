{
   
    rels: {

        "PTRNPF_TransactionDetail" : {
            "to": "TransactionDetail",
                "cardinality": "one",
                    "direction": "out",
                        "id": function(input, state) {
                            if (input && input.chdrnum && input.batctrcde && input.tranno)
                                return "LA::Pru::TransactionDetail::" + input.chdrnum + "_" + input.batctrcde + "_" + input.tranno;
                            return null;
                        }
        }
    }
}