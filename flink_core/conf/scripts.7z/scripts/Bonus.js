{

    targets: {

        "Bonus_Target" : {
            type: "Bonus"
        }
    },

    rels: {

        "BONSPF_Bonus" : {
            "to": "LifeAsia.BONSPF",
                "cardinality": "one",
                    "direction": "in"
        },

        "Bonus_Policy" : {
            "to": "Policy",
                "cardinality": "one",
                    "direction": "out"
        }
    }
}