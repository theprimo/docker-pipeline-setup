{
        
    rels: {
        "CLRRPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.forenum && input.forenum.toString() && input.forenum.toString().substr(0,8) && input.forenum.toString().substr(0,8).length == 8 && (input.clrrrole == "NE" ||input.clrrrole == "TR" || input.clrrrole == "AP")) 
                return "LA::Pru::Policy::" + input.forenum.toString().substr(0,8);
                return null;
            }
        },
        "CLRRPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.forenum && input.forenum.toString() && input.forenum.toString().substr(0,8) && input.forenum.toString().substr(0,8).length == 8 && (input.clrrrole == "NE" ||input.clrrrole == "TR" || input.clrrrole == "AP")) 
                return "LA::Pru::Proposal::" + input.forenum.toString().substr(0,8);
                return null;
            }
        }
       
    }
}

