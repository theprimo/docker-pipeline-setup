{
    
    targets: {
        
        "Proposal_Target": {
            type: "Proposal"
        }
    },
    
    rels: {
        
        "CHDRPF_Proposal": {
            "to": "LifeAsia.CHDRPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "StaticData_Proposal" : {
            "to": "StaticData",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input)
                return "LifeAsia::DESCPF::IT_T54472";
                return null;
            }
        },
        
        
        "TTRCPF_Proposal" : {
            "to": "LifeAsia.TTRCPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "HPADPF_Proposal": {
            "to": "LifeAsia.HPADPF",
            "cardinality": "one",
            "direction": "in"
        },
        "Proposal_beneficiaries" : {
            "to": "Beneficiary",
            "cardinality": "many",
            "field": "beneficiaries",
            "direction": "in"
            
        },
        "BNFYPF_Proposal" : {
            "to": "LifeAsia.BNFYPF",
            "cardinality": "many",
            "direction": "in"
        },
        "BEXTPF_Proposal" : {
            "to": "LifeAsia.BEXTPF",
            "cardinality": "many",
            "direction": "in"
        },
        "CLRRPF_Proposal": {
            "to": "LifeAsia.CLRRPF",
            "cardinality": "one",
            "direction": "in"
        },
        "LIFEPF_Proposal" : {
            "to": "LifeAsia.LIFEPF",
            "cardinality": "many",
            "direction": "in"
        },
        "COVRPF_Proposal" : {
            "to": "LifeAsia.COVRPF",
            "cardinality": "one",
            "direction": "in"
        },
        "FLUPPF_Proposal" : {
            "to": "LifeAsia.FLUPPF",
            "cardinality": "many",
            "direction": "in"
        },
    }
}
