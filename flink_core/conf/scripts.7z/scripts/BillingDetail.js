{
    
    targets: {
        
        "BillingDetail_Target" : {
            type: "BillingDetail"
        }
    },
    
    rels: {
        
        "MANDPF_BillingDetail" : {
            "to": "LifeAsia.MANDPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "BEXTPF_BillingDetail" : {
            "to": "LifeAsia.BEXTPF",
            "cardinality": "one",
            "direction": "in"
        },

        "BillingDetail_Policy":{
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.polno)
                {
                    return "LA::Pru::Policy::" + input.polno;
                }
                return null;
            }
        },
        
        
        "PAYRPF_BillingDetail" : {
            "to": "LifeAsia.PAYRPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        
        "BillingDetail_Customer" : {
            "to": "Customer",
            "cardinality": "one",
            "field": "customer",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.policyOwner)
                return "LA::Pru::Customer::" + input.policyOwner;
                return null;
            }
            
        }
        
        
    }
    
}
