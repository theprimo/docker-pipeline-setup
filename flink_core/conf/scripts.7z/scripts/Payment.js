{
    
    targets: {    
        "Payment_Target": {
            type: "Payment"
        }
    },
    
    rels: {
        
        "RTRNPF_Payment": {
            "to": "LifeAsia.RTRNPF",
            "cardinality": "one",
            "direction": "in"
        },
        "StaticData_Payment" : {
            "to": "StaticData",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input)
                return "LifeAsia::DESCPF::IT_T1688";
                return null;
            }
        }
    }
}