{
	
	targets: {
		
		"ProductOption_Target" : {
			type: "ProductOption"
		}
	},
	
	rels: {
		"COVRPF_ProductOption" : {
			"to": "LifeAsia.COVRPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"COVRPF_ProductOption_Many": {
            "to": "LifeAsia.COVRPF",
            "cardinality": "many",
            "direction": "in"
		},
		
		"ProductOption_Policy" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"field": "policy",
			"id": function(input, state) {
				if (input && input.chdrnum)
				return "LA::Pru::Policy::" + input.chdrnum;
				return null;
			}
		},
		
		//TODO: productComponentOptions are not defined in the domain model
		
		"ProductComponentOption_ProductOption" : {
			"to": "ProductComponentOption",
			"cardinality": "many",
			"field": "productComponentOptions",
			"direction": "in"
		},
		
		//TODO productoption in policy?
		"AGCMPF_ProductOption" : {
			"to": "LifeAsia.AGCMPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"LEXTPF_ProductOption" : {
			"to": "LifeAsia.LEXTPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"INCIPF_ProductOption" : {
			"to": "LifeAsia.INCIPF",
			"cardinality": "one",
			"direction": "in"
		}
		
	}
}