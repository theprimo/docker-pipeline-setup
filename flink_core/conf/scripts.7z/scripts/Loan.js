{
    
    targets: {
        
        "Loan_Target" : {
            type: "Loan"
        }
    },
    
    rels: {
        
        "LOANPF_Loan" : {
            "to": "LifeAsia.LOANPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "Loan_Policy" : {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out"
        }
    }
}