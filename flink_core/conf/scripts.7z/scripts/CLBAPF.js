{
  
  rels: {
    "CLBAPF_Customer": {
      "to": "Customer",
      "cardinality": "one",
      "direction": "out",
      "id": function (input, state) {
        if (input && input.clntnum)
        return "LA::Pru::Customer::" + input.clntnum;
        return null;
      }
      
    }
    
  }
}