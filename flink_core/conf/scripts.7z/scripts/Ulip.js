{

    targets: {
        "Ulip_Target" : {
            type: "Ulip"
        }
    },

    rels: {

        "UTRNPF_Ulip" : {
            "to": "LifeAsia.UTRNPF",
                "cardinality": "one",
                    "direction": "in"
        }

        /*"ULNKPF_Ulip" : {
            "to": "LifeAsia.ULNKPF",
                "cardinality": "many",
                    "direction": "in",
                        transform: function(input, output, state, operation) {
                            if (input) {
                                output.Ulip_Target = input;
                            }
                        }
        },

        "INLTPF_Ulip" : {
            "to": "LifeAsia.INLTPF",
            "cardinality": "many",
            "direction": "in",
            transform: function(input, output, state, operation) {
                if (input) {								
                    output.Ulip_Target = input;
                }
            }
        }*/
    }
}