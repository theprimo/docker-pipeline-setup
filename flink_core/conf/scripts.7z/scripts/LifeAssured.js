{
    
    targets: {
        "LifeAssured_Target" : {
            type: "LifeAssured"
        }
    },
    
    rels: {
        "LIFEPF_LifeAssured" : {
            "to": "LifeAsia.LIFEPF",
            "cardinality": "one",
            "direction": "in",
        },

        "CLNTPF_LifeAssured" : {
            "to": "LifeAsia.CLNTPF",
            "cardinality": "one",
            "direction": "in",
        },

        "UWQSPF_LifeAssured" : {
            "to": "LifeAsia.UWQSPF",
            "cardinality": "one",
            "direction": "in",
        }
    }
}