{
    
    targets: {
        
        "Beneficiary_Target" : {
            type: "Beneficiary"
        }
    },
    
    rels: {
        
        "BNFYPF_Beneficiary" : {
            "to": "LifeAsia.BNFYPF",
            "cardinality": "one",
            "direction": "in"
        },
        "Beneficiary_Policy_Validflag": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.polno)
                    return "LA::Pru::Policy::" + input.polno;
                return null;
            }
        },
        "Policy_beneficiaries":{
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.polno)
                return "LA::Pru::Policy::" + input.polno;
                return null;
            }
        },
        "Proposal_beneficiaries":{
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.polno)               
                return "LA::Pru::Proposal::" + input.polno;
                return null;
            }
        }
    }
}