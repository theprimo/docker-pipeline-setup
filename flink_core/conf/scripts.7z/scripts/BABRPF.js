{
  
  rels: {
    "BABRPF_StaticData": {
      "to": "StaticData",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.bankkey && input.bankdesc)
                return "LifeAsia::BABRPF::" + input.bankkey;
              return null;
            }
    } 

  }
}