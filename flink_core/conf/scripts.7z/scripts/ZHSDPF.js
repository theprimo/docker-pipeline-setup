{
        
    rels: {
        "ZHSDPF_Hospital": {
            "to": "Hospital",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if(input && input.chdrnum)
                                return "LA::Pru::Hospital::"+input.chdrnum;
                            return null;
                        }

        }
    }
}

