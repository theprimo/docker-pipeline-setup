{
        
    rels: {
        "BNFYPF_Beneficiary": {
            "to": "Beneficiary",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                //print('line no 33 BNFYPF_Beneficiary'+input.bnyclt)
                if (input && input.chdrnum && input.bnyclt)
                return "LA::Pru::Beneficiary" + "::" + input.chdrnum + "_" + input.bnyclt;
                return null;
            }
        },
        "BNFYPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                //print('line no 33 BNFYPF_Beneficiary'+input.bnyclt)
                if (input && input.chdrnum)
                return "LA::Pru::Policy" + "::" + input.chdrnum;
                return null;
            }
        },
        "BNFYPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                //print('line no 33 BNFYPF_Beneficiary'+input.bnyclt)
                if (input && input.chdrnum)
                return "LA::Pru::Proposal" + "::" + input.chdrnum;
                return null;
            }
        }                   
    }
}