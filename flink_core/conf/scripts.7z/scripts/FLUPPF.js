{
    
    rels: {
        
        "FLUPPF_FollowUp": {
            "to": "FollowUp",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.fupcode && input.fupno)
                return "LA::Pru::FollowUp::" + input.chdrnum + "_" + input.life + "_" + input.fupcode + "_" + input.fupno;
                return null;
            }
        },
        "FLUPPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum){
                 return "LA::Pru::Policy::" + input.chdrnum +'_'+input.life;
                }
                return null;
            }
            /*transform: function(input, output, state, operation) {
                var body = { life:"", jointLife:"" };

                if(input.lifeDetails.life == "01"){ body.life = "LA::Pru::Customer::" + input.lifeDetails.lifcnum; }
                if(input.lifeDetails.life != "01"){ body.jointLife = "LA::Pru::Customer::" + input.lifeDetails.lifcnum; }

                output.FLUPPF_FollowUp = body;FLUPPF_Proposal
            }*/
        },
        "FLUPPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.fupcode && input.fupno)
                return "LA::Pru::Proposal::" + input.chdrnum + "_" + input.life;
                return null;
            }
        },
    }
}
