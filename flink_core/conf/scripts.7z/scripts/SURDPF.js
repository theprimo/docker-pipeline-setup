{
   
    rels: {

        "SURDPF_Surrender": {
            "to": "Surrender",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.chdrnum && input.life && input.coverage && input.rider)
                                return "LA::Pru::Surrender::" + input.chdrnum + "_" + input.life + "_" + input.coverage + "_" + input.rider;
                            return null;
                        }
        }
    }
}

