{
   
    rels: {
        "CHDRPF_COVRPF" : {
            "to": "LifeAsia.COVRPF",
            "cardinality": "many",
            "direction": "in"
        },

        "CHDRPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.validflag && input.validflag == "1")
                    return "LA::Pru::Policy::" + input.chdrnum;                
                return null;
            }
        },
        
        "CHDRPF_Customer": {
            "to": "Customer",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.cownnum && input.validflag && input.validflag == "1")
                    return "LA::Pru::Customer" + "::" + input.cownnum;
                return null;
            }
        },
        
        "CHDRPF_Agent": {
            "to": "Agent",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.agntnum && input.validflag && input.validflag == "1")
                    return "LA::Pru::Agent" + "::" + input.agntnum;
                return null;
            }
        },
        
        "CHDRPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.validflag && input.validflag == "3")
                    return "LA::Pru::Proposal::" + input.chdrnum;
                return null;
            }
        },

        "CHDRPF_Policy_ValidFlag": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.validflag && input.validflag == "1")
                    return "LA::Pru::Policy::" + input.chdrnum;
                return null;
            }
        },

    }
}
