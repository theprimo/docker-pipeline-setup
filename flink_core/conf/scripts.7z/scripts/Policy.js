{
    
    targets: {
        
        "Policy_Target": {
            type: "Policy"
        }
    },
    
    rels: {
        
        "COVRPF_Policy": {
            "to": "LifeAsia.COVRPF",
            "cardinality": "one",
            "direction": "in"
        },

        "COVRPF_Policy_Many": {
            "to": "LifeAsia.COVRPF",
            "cardinality": "many",
            "direction": "in"
        },

        "BEXTPF_Policy": {
            "to": "LifeAsia.BEXTPF",
            "cardinality": "one",
            "direction": "in"
        },

        "BEXTPF_Policy_Many": {
            "to": "LifeAsia.BEXTPF",
            "cardinality": "many",
            "direction": "in"
        },

        "CLRRPF_Policy": {
            "to": "LifeAsia.CLRRPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "CHDRPF_Policy": {
            "to": "LifeAsia.CHDRPF",
            "cardinality": "one",
            "direction": "in"
        },
		
		 "ProductComponentOption_Policy" : {
            "to": "ProductComponentOption",
            "cardinality": "many",
            "direction": "in",
            
        },
        
        "Claim_Policy" : {
            "to": "Claim",
            "cardinality": "many",
            "direction": "in",
        },
        
        "Policy_Customer" : {
            "to": "Customer",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.cownnum)
                return "LA::Pru::Customer::" + input.cownnum;
                return null;
            }
        },
        
        "BillingDetail_Policy": {
            "to": "BillingDetail",
            "cardinality": "many",
            "field": "billingDetail",
            "direction": "in"
        },
        
        // "Agent_ServicingAgents_Policy": {
        //     "to": "Agent",
        //     "cardinality": "many",
        //     "field": "servicingAgents",
        //     "direction": "in"
        // },
        
        "BNFYPF_Policy" : {
            "to": "LifeAsia.BNFYPF",
            "cardinality": "many",
            "direction": "in"
        },
        
        "LIFEPF_Policy" : {
            "to": "LifeAsia.LIFEPF",
            "cardinality": "one",
            "direction": "in"
            /*transform: function(input, output, state, operation) {
                output.Policy_Target = input;
            }*/
        },
        
        "Customer_Policy" : {
            "to": "Customer",
            "cardinality": "many",
            "field": "payers",
            "direction": "in"
        },
        
        
        "ProductOption_Policy" : {
            "to": "ProductOption",
            "cardinality": "many",
            "field": "productOptions",
            "direction": "in"
            
        },
        
        "Customer_Policy_clients" : {
            "to": "Customer",
            "cardinality": "many",
            "field": "clients",
            "direction": "in"
            
        },
        
        "Policy_beneficiaries" : {
            "to": "Beneficiary",
            "cardinality": "many",
            "field": "beneficiaries",
            "direction": "in"
            
        },
        
        "Customer_Policy_lifeAssured" : {
            "to": "Customer",
            "cardinality": "many",
            //"field": "lifeAssured",
            "direction": "in"            
        },
        
        "Bonus_Policy" : {
            "to": "Bonus",
            "cardinality": "many",
            "direction": "in"
            
        },
        
        "Surrender_Policy" : {
            "to": "Surrender",
            "cardinality": "one",
            "field": "surrender",
            "direction": "in"
            
        },
        
        "Loan_Policy" : {
            "to": "Loan",
            "cardinality": "one",
            "field": "loans",
            "direction": "in"
        },
        
        "LIFEPF_Policy": {
            "to": "LifeAsia.LIFEPF",
            "cardinality": "many",
            "direction": "in"
        },

        "IPHDPF_Policy": {
            "to": "LifeAsia.IPHDPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "REFFPF_Policy": {
            "to": "LifeAsia.REFFPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        /*"ZPDFPF_Policy" : {
            "to": "LifeAsia.ZPDFPF",
            "cardinality": "one",
            "direction": "in",
            transform: function(input, output, state, operation) {
                if (input) {								
                    output.Policy_Target = input;
                }
            }
        },*/
        
        // "PartialSurrender_Policy" : {
        //     "to": "PartialSurrender",
        //     "cardinality": "many",
        //     "field": "partialSurrenders",
        //     "direction": "in"
        // },
        
        "FollowUp_Policy" : {
            "to": "FollowUp",
            "cardinality": "many",
            "field": "followUp",
            "direction": "in"
        },
        
        "Customer_Policy_Assignee" : {
            "to": "Customer",
            "cardinality": "many",
            "field": "assignee",
            "direction": "in"
        },
        
        "Customer_Policy_Trustee" : {
            "to": "Customer",
            "cardinality": "many",
            "field": "trustee",
            "direction": "in"
        },
        
        "Customer_Policy_Appointee" : {
            "to": "Customer",
            "cardinality": "many",
            "field": "appointee",
            "direction": "in"
        },
        
        "HPADPF_Policy" : {
            "to": "LifeAsia.HPADPF",
            "cardinality": "one",
            "direction": "in"
        },
        "LIFEPF_Policy_FLUPPF" : {
            "to": "LifeAsia.LIFEPF",
            "cardinality": "one",
            "direction": "in"
        },
        "FLUPPF_Policy" : {
            "to": "LifeAsia.FLUPPF",
            "cardinality": "many",
            "direction": "in"
        },
        "CHDRPF_Policy_ValidFlag" : {
            "to": "LifeAsia.CHDRPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "Beneficiary_Policy_Validflag" : {
            "to": "Beneficiary",
            "cardinality": "many",
            "direction": "in"
        }
        
    }
} 

