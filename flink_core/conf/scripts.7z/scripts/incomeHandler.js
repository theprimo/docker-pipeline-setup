function populateIncomeCLADPF(mthincam, yrincam, zsrcsald) {
    if (zsrcsald != '') {
        var income = new Object();
        if (mthincam != '') {
            income.frequency = 'Monthly';
            income.amount = mthincam;
        } else if (yrincam != '') {
            income.frequency = 'Yearly';
            income.amount = yrincam;
        }
        income.source = zsrcsald;
        return income;
    }
}