{
        
    rels: {
        
        "DESCPF_Product": {
            "to": "Product",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.descitem && input.desctabl && input.desctabl.toUpperCase() == "T5688" ) {
                    return "LA::Pru::Product::" + input.descitem;
                }
                return null;
            }
        },
        
        "DESCPF_ProductComponent": {
            "to": "ProductComponent",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.descitem && input.desctabl && input.desctabl.toUpperCase() == "T5687")
                return "LA::Pru::ProductComponent::" + input.descitem;
                return null;
            }
        },
        
        "DESCPF_StaticData": {
            "to": "StaticData",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.descpfx && input.desctabl && (input.desctabl.toUpperCase() == "T3645" || input.desctabl.toUpperCase() == "T5447" || input.desctabl.toUpperCase() == "T6692" || input.desctabl.toUpperCase() == "TT518" || input.desctabl.toUpperCase() == "T3644" || input.desctabl.toUpperCase() == "T1688" ) )
                return "LifeAsia::DESCPF::" + input.descpfx + "_" + input.desctabl;
                return null;
            }
        }
    }
}