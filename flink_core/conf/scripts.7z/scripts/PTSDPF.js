{
    
    rels: {
        "PTSDPF_PartialSurrender": {
            "to": "PartialSurrender",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.virtual_fund && input.tranno)
                return "LA::Pru::PartialSurrender::"+input.chdrnum+"_"+input.virtual_fund+"_"+input.tranno;
                return null;
            }
            
        }
    }
}  
    

