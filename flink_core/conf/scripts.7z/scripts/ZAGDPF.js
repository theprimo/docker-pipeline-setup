{
    
    rels: {
  
        "ZAGDPF_Agent" : {
            "to": "Agent",
                "cardinality": "one",
                    "direction": "out",
                        "id": function(input, state) {
                            //need to discuss
                            if (input && input.agntnum)
                                return "LA::Pru::Agent::" + input.agntnum ;
                            return null;
                        }

        }
    }
}
