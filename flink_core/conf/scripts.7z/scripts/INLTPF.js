{
   
    rels: {
        "INLTPF_Ulip": {
            "to": "Ulip",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider )
                    return "LA::Pru::ULIP::"+input.chdrnum+"_"+input.life+"_"+input.coverage+"_"+input.rider;
                return null;
            }
            
        }
    }
}

