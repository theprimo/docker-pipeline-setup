{
    
    targets: {
        "PartialSurrender_Target" : {
            type: "PartialSurrender"
        }
    },
    
    rels: {
        
        "PTSDPF_PartialSurrender" : {
            "to": "LifeAsia.PTSDPF",
            "cardinality": "one",
            "direction": "in"
        },
       

         
        "PartialSurrender_Policy" : {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.policy) 
                return "LA::Pru::Policy::"+input.policy;
                return null;
            }
        }
        
        
    }
    
    
}