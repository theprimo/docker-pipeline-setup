{
    
    targets: {
        
        "FollowUp_Target" : {
            type: "FollowUp"
        }
    },
    
    rels: {
        
        "FLUPPF_FollowUp" : {
            "to": "LifeAsia.FLUPPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "FollowUp_Policy" : {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                    if (input && input.polno) {
                        return "LA::Pru::Policy::" + input.polno;
                    }
                    return null;
                }
        },
        "StaticData_FollowUp" : {
            "to": "StaticData",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input)
                return "LifeAsia::DESCPF::IT_T5661";
                return null;
            }
        }
    }
}