{
        
    rels: {
        "PTSHPF_PartialSurrender": {
            "to": "PartialSurrender",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.life && input.coverage && input.rider )
                return "LA::Pru::PartialSurrender::"+input.chdrnum+"_"+input.life+"_"+input.coverage+"_"+input.rider;
                return null;
            }
            
        }
    }
   
}

