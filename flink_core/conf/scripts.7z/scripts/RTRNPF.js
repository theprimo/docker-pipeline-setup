{
        
    rels: {
        
        "RTRNPF_Payment" : {
            "to": "Payment",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.rldgacct && input.batctrcde && input.tranno && input.effdate && (["B522","T536","T607","T642","T646","T656"].indexOf(input.batctrcde) != -1)){
                    return "LA::Pru::Payment::" + input.rldgacct.slice(0, 8) + "_" + input.batctrcde + "_" + input.tranno + "_" + (input.effdate).replace(/-/g, "");
                return null;
                }
            }
        }
    }
}