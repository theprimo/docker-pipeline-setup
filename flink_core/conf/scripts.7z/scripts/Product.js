{

    targets: {
        
        "Product_Target" : {
            type: "Product"
        }
    },

    rels: {

        "DESCPF_Product" : {
            "to": "LifeAsia.DESCPF",
                "cardinality": "one",
                    "direction": "in"
        },

        "ITEMPF_Product" : {
            "to": "LifeAsia.ITEMPF",
                "cardinality": "one",
                    "direction": "in"
        },

        "ZQPRPF_Product" : {
            "to": "LifeAsia.ZQPRPF",
                "cardinality": "one",
                    "direction": "in"
        },

        "Product_Agent" : {
            "to": "Agent",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {                            
                            if (input && input.agntnum) {                                
                                return "LA::Pru::Agent::" + input.agntnum;
                            }
                            return null;
                        }
        }
    }
}