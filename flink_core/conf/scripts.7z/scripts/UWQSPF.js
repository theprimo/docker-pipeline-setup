{
        
    rels: {
        "UWQSPF_Customer": {
            "to": "Customer",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.lifcnum)
                return "LA::Pru::Customer::" + input.lifcnum;
                return null;
            }
        },
        //Arjun Changes
        "UWQSPF_LifeAssured": {
            "to": "LifeAssured",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.lifcnum)
                return "LA::Pru::LifeAssured::" + input.lifcnum;
                return null;
            }
        }
    }
}