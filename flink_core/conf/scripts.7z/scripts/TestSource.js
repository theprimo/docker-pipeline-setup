function transform(message, out) {
    var newMessage = GenericMessage.create();
    var newVarJSON = JSON.parse(message);
    
    var newVarJSONID = "";
    var entityType = "";
    var srcTableName = (newVarJSON.data.src_table_name ? newVarJSON.data.src_table_name : "None")
    var ignoreMsg = "NO";
    
    switch (srcTableName.toLowerCase()) {
        case "zedapf":
        entityType = "Agent";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "zqprpf":
        entityType = "Product";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "clbapf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.bankacckey.replace(/ /g, "").toLowerCase() + "_" + newVarJSON.data.bankkey.replace(/ /g, "").toLowerCase() + "_" + newVarJSON.data.clntcoy + "_" + newVarJSON.data.clntnum;
        break;
        case "clntpf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.clntnum;
        if (newVarJSON.data.validflag && newVarJSON.data.validflag != "1") {
            ignoreMsg = "YES";
        }
        break;
        case "clexpf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.clntpfx + "_" + newVarJSON.data.clntcoy + "_" + newVarJSON.data.clntnum
        if (newVarJSON.data.validflag && newVarJSON.data.validflag != "1") {
            ignoreMsg = "YES";
        }
        break;
        case "cladpf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.rrn;
        if (newVarJSON.data.validflag && newVarJSON.data.validflag != "1") {
            ignoreMsg = "YES";
        }
        break;
        case "cldppf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.rrn;
        if (newVarJSON.data.validflag && newVarJSON.data.validflag != "1") {
            ignoreMsg = "YES";
        }
        break;
        case "babrpf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.bankkey.replace(/ /g, "").toLowerCase();
        break;
        case "lifepf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "linspf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "bextpf":
        entityType = "BillingDetail";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "payrpf":
        entityType = "BillingDetail";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "mandpf":
        entityType = "BillingDetail";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "rtrnpf":
        entityType = "Payment";
        newVarJSONID = newVarJSON.data.rrn; 
        break;
        case "ptrnpf":
        entityType = "TransactionDetail";
        newVarJSONID = newVarJSON.data.rrn; 
        break;
        case "acmvpf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn; //newVarJSON.data.rldgacct.slice(0,8)
        break;
        case "lethpf":
        entityType = "BillingInvoice"; 
        newVarJSONID = newVarJSON.data.clntcoy + "_" + newVarJSON.data.clntnum + "_" + newVarJSON.data.hsublet + "_" + newVarJSON.data.letter_seqno + "_" + newVarJSON.data.letter_type + "_" + newVarJSON.data.request_company
        break;
        case "uwqspf":
        entityType = "Customer";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "covrpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.chdrcoy + "_" + newVarJSON.data.chdrnum + "_" + newVarJSON.data.life + "_" + newVarJSON.data.coverage + "_" + newVarJSON.data.rider + "_" + newVarJSON.data.tranno
        break;
        case "chdrpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.chdrnum;
        break;
        case "bnfypf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "claipf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "regppf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "clmhpf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn
        break;
        case "clmdpf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "ihnspf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.rrn
        break;
        case "zclhpf":
        entityType = "Claim";
        newVarJSONID = newVarJSON.data.chdrnum;
        break;
        case "descpf":
        entityType = "Product";
        newVarJSONID = newVarJSON.data.descpfx + "_" + newVarJSON.data.desccoy + "_" + newVarJSON.data.desctabl + "_" + newVarJSON.data.descitem + "_" + newVarJSON.data.itemseq + "_" + newVarJSON.data.language
        break;
        case "itempf":
        entityType = "Product";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "zhsppf":
        entityType = "Hospital";
        newVarJSONID = newVarJSON.data.hospcd;
        break;
        case "aglfpf":
        entityType = "Agent";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "agntpf":
        entityType = "Agent";
        newVarJSONID = newVarJSON.data.agntpfx + "_" + newVarJSON.data.agntcoy + "_" + newVarJSON.data.agntnum
        break;
        //budi added
        case "macfpf":
        entityType = "Agent"
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "zagdpf":
        entityType = "Agent"
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "covtpf":
        entityType = "Proposal"
        newVarJSONID = newVarJSON.data.chdrcoy + "_" + newVarJSON.data.chdrnum + "_" + newVarJSON.data.life + "_" + newVarJSON.data.coverage + "_" + newVarJSON.data.rider;
        break;
        case "hpadpf":
        entityType = "Policy"
        newVarJSONID = newVarJSON.data.chdrcoy + "_" + newVarJSON.data.chdrnum;
		break;
		case "zapdpf":
        case "zhagpf":
        entityType = "Agent";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "inltpf":
        entityType = "ULIP"
        newVarJSONID = newVarJSON.data.rrn;
        break;
        //budi added
        case "ttrcpf":
        entityType = "Proposal";
        newVarJSONID = newVarJSON.data.rrn;
		break;
	    case "utrnpf":
        entityType = "ULIP";
        newVarJSONID = newVarJSON.data.rrn;
		break;
		case "bonspf":
        entityType = "Bonus";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "loanpf":
        entityType = "Loan";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "surdpf":
        entityType = "Surrender";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "lextpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "agcmpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "iphdpf":
        case "reffpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "ptsdpf":
        case "ptshpf":
        entityType = "PartialSurrender";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "fluppf":
        entityType = "FollowUp";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "incipf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "ulnkpf":
        entityType = "ULIP";
        newVarJSONID = newVarJSON.data.rrn;
        break;
        case "zpdfpf":
        entityType = "Policy";
        newVarJSONID = newVarJSON.data.rrn;
		break;
		//hartono added - 5 April 2019
		case "clrrpf":
		newVarJSONID = newVarJSON.data.clntpfx + "_" + newVarJSON.data.clntcoy + "_" + newVarJSON.data.clntnum + "_" + newVarJSON.data.clrrrole + "_" + newVarJSON.data.forepfx + "_" + newVarJSON.data.forecoy + "_" + newVarJSON.data.forenum;
		break;
		case "utrspf":
		newVarJSONID = newVarJSON.data.chdrcoy + "_" + newVarJSON.data.chdrnum + "_" + newVarJSON.data.life + "_" + newVarJSON.data.coverage + "_" + newVarJSON.data.rider + "_" + newVarJSON.data.unit_virtual_fund + "_" + newVarJSON.data.plan_suffix + "_" + newVarJSON.data.unit_type;
		break;
		case "payrpf":
		newVarJSONID = newVarJSON.data.chdrcoy + "_" + newVarJSON.data.chdrnum + "_" + newVarJSON.data.payrseqno;
		break;
		//hartono end
//hartono added 5 April 2019
		case "zagnpf":
		case "hbnfpf":
		case "vprcpf":
		case "zrnbpf":
		case "ihbppf":
		case "ihbepf":
		case "zaltpf":
		case "zpdrpf":
		case "hclmpf":
		case "zdcrpf":
		case "zdglpf":
		case "zohppf":
		case "hbclpf":
		case "zncbpf":
		//hartono end
		//wiri added 29 May 2019 for PMN
		case "clscpf":
		case "acsrpf":
		case "aschpf":
		case "bcsrpf":
		case "isblpf":
		case "rfuppf":
		case "zcldpf":
		case "zclhpf":
		case "zhsppf":
		case "hxclpf":
		case "ihbypf":
		//end wiri added 29 May 2019 for PMN
		newVarJSONID = newVarJSON.data.rrn;
		break;
        default:
        entityType = "None";
        newVarJSONID = new Date().getTime().toString();
        break
    }
    
    //TODO ,ACMVPF ,CLMHPF,COVTPF,RTRNPF, PTRNPF
    var operationType = newVarJSON.data.SRC_CDC_OPERATION;
    newVarJSONID += ((newVarJSONID == "" )? new Date().getTime().toString().replace(" ",""): "")
   
    newMessage.addProperty("id", srcTableName + "::" + newVarJSONID);
    if (operationType == "UPDATE") {
        newMessage.operation = "updateEntity";
    } else if (operationType == "CREATE" || operationType == "INSERT" || operationType == "REFRESH") {
        newMessage.operation = "updateEntity";
    } else if (operationType == "DELETE") {
        newMessage.operation = "deleteEntity";
    } else {
        newMessage.operation = "updateEntity";
    }
    newMessage.addProperty("entityType", srcTableName);
    newMessage.addProperty("srcEntityName", entityType);
    newMessage.addProperty("dbInstance", "LifeAsia");
    newMessage.source = _config.name;
    newMessage.bodyAsString = JSON.stringify(cleanseRaw(newVarJSON.data));
    if (ignoreMsg == "NO") {
        out.collect(newMessage);
    }
}

function cleanseRaw(obj) {
    for (var propName in obj) {
        if (obj[propName] === null) {
            delete obj[propName];
        }
    }
    return obj;
}