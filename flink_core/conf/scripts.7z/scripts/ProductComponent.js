{
    
    targets: {
        
        "ProductComponent_Target" : {
            type: "ProductComponent"
        }
    },
    
    rels: {
        
        "DESCPF_ProductComponent" : {
            "to": "LifeAsia.DESCPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "ITEMPF_ProductComponent" : {
            "to": "LifeAsia.ITEMPF",
            "cardinality": "one",
            "direction": "in"
        }
    }
}