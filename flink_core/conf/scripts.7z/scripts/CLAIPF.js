{
    
    rels: {

        "CLAIPF_Claim": {
            "to": "Claim",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.chdrnum && input.life && input.rgpynum)
                                return "LA::Pru::Claim::" + input.chdrnum + "_" + input.life + "_" + input.rgpynum;
                            return null;
                        }
        }
    }
}