{
    
    rels: {

        "REGPPF_Claim": {
            "to": "Claim",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.chdrnum && input.life && input.coverage && input.rider && input.rgpynum)
                                return "LA::Pru::Claim::" + input.chdrnum + "_" + input.life + "_" + input.coverage + "_" + input.rider + "_" + input.rgpynum;
                            return null;
                        }
        }
    }
}