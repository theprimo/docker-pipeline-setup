{
        
    rels: {
        
        
        "HPADPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.validflag && input.validflag == "1")
                    return "LA::Pru::Policy" + "::" + input.chdrnum;
                return null;
            }
        },
        
        "HPADPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.validflag && input.validflag == "1") //check, why 1?
                    return "LA::Pru::Proposal::" + input.chdrnum;
                return null;
            }
        }
    }
}
