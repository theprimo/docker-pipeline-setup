{
    rels: {

        "LETHPF_BillingInvoice": {
            "to": "BillingInvoice",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.clntnum && input.letter_type && input.letter_seqno)
                                return "LA::Pru::BillingInvoice::" + input.clntnum + "_" + input.letter_type + "_" + input.letter_seqno;
                            return null;
                        }
        }
    }
}