{
  
  rels: {

    "AGNTPF_Agent": {
      "to": "Agent",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.agntnum)
                return "LA::Pru::Agent::" + input.agntnum;
              return null;
            }
    },
    "AGNTPF_Customer": {
      "to": "Customer",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.clntnum)
                return "LA::Pru::Customer::" + input.clntnum;
              return null;
            }
    }
  }
}