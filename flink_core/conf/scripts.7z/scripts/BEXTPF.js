{
    
    rels: {
        "BEXTPF_Customer" : {
            "to": "Customer",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.payrnum){
                    return "LA::Pru::Customer::" + input.payrnum;
                }
                return null;
            }
        },

        "BEXTPF_Policy_Many" : {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.chdrnum){
                    return "LA::Pru::Policy::" + input.chdrnum;
                }
                return null;
            }
        },

        "BEXTPF_Policy" : {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.chdrnum){
                    return "LA::Pru::Policy::" + input.chdrnum;
                }
                return null;
            }
        },
        "BEXTPF_Proposal" : {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                if (input && input.chdrnum){
                    return "LA::Pru::Proposal::" + input.chdrnum;
                }
                return null;
            }
        },
        
        "BEXTPF_BillingDetail" : {
            "to": "BillingDetail",
            "cardinality": "one",
            "direction": "out",
            "id": function(input, state) {
                // if (input && (input.payrnum || input.mandref))
                //     return "LA::Pru::BillingDetail::" + input.payrnum + "_" + input.mandref;
                if (input && (input.chdrnum && input.bankkey))
                return "LA::Pru::BillingDetail::" + input.chdrnum + "_" + input.bankkey;
                return null;
            }
        }
    }
}

