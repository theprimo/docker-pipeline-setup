function getFormattedDate(val){
    var formattedDate ="9999-12-31";
    if(val && val.toString() && val.toString() != "99999999" && val.toString().length == 8)
    {
        formattedDate = val.toString().slice(0, 4) + "-" + val.toString().slice(4, 6) + "-" + val.toString().slice(6, 8);
    }
    else if(val && val.toString() && val.toString() != "999999" && val.toString().length == 6)
    {
        var yearPart = parseInt(val.toString().slice(0, 2));
        var year = yearPart <= 19 && yearPart >= 00 ? "20"+yearPart : "19"+yearPart;
        formattedDate = year + "-" + val.toString().slice(2, 4) + "-" + val.toString().slice(4, 6);

    }
    return formattedDate;
}

