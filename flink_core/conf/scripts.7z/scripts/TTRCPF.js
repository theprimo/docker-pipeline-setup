{
        
    rels: {
        "TTRCPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
					return "LA::Pru::Proposal::" + input.chdrnum;
                return null;
            }
            
        }
    }
}

