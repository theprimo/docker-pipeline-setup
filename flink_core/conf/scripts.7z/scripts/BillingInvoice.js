{

    targets: {

        "BillingInvoice_Target" : {
            type: "BillingInvoice"
        }
    },

    rels: {

        "LETHPF_BillingInvoice" : {
            "to": "LifeAsia.LETHPF",
                "cardinality": "one",
                    "direction": "in"
        }
    }
}