{
       
    rels: {
        
        "LOANPF_Loan": {
            "to": "Loan",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum && input.loan_number)
                return "LA::Pru::Loan::" + input.chdrnum + "_" + input.loan_number;
                return null;
            }
        }
    }
}

