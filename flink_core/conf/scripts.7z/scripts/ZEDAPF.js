{
    
    rels: {

        "ZEDAPF_Agent": {
            "to": "Agent",
                "cardinality": "one",
                    "direction": "out",
                    "id": function (input, state) {
                        if (input && input.agntnum)
                            return "LA::Pru::Agent" + "::" + input.agntnum;
                        return null;
                    }
        }

    }
}