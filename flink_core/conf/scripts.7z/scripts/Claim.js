{

	targets: {

		"Claim_Target" : {
			type: "Claim"
		}
	},

	rels: {

		"REGPPF_Claim" : {
			"to": "LifeAsia.REGPPF",
				"cardinality": "one",
					"direction": "in"
		},

		"StaticData_Claim" : {
			"to": "StaticData",
				"cardinality": "one",
					"direction": "out",
						"id": function(input, state) {
							if (input && input.payreason)
								return "LifeAsia::DESCPF::IT_T6692";
							return null;
						}
		},

		"CLMHPF_Claim" : {
			"to": "LifeAsia.CLMHPF",
				"cardinality": "one",
					"direction": "in"
		},

		"Claim_Customer" : {
			"to": "Customer",
				"cardinality": "one",
					"field": "client",
						"direction": "out",
							"id": function(input, state) {
								if (input && input.clmparty)
									return "LA::Pru::Customer::" + input.clmparty;
								return null;
							}

		},

		"ACMVPF_Claim" : {
			"to": "LifeAsia.ACMVPF",
				"cardinality": "one",
					"direction": "in"
		},

		"CLAIPF_Claim" : {
			"to": "LifeAsia.CLAIPF",
				"cardinality": "one",
					"direction": "in"
		},

		"CLMDPF_Claim" : {
			"to": "LifeAsia.CLMDPF",
				"cardinality": "one",
					"direction": "in"
		},

		"IHNSPF_Claim" : {
			"to": "LifeAsia.IHNSPF",
				"cardinality": "one",
					"direction": "in"
		},

		"ZCLHPF_Claim" : {
			"to": "LifeAsia.ZCLHPF",
				"cardinality": "one",
					"direction": "in"
		},

		"ACMVPF_RegularClaimSettlementDate" : {
			"to": "LifeAsia.ACMVPF",
				"cardinality": "one",
					"direction": "in"
		},

		"ACMVPF_DeathClaimSettlementDate" : {
			"to": "LifeAsia.ACMVPF",
				"cardinality": "one",
					"direction": "in"
		},

		"Claim_Policy" : {
			"to": "Policy",
				"cardinality": "one",
					"field" : "policy",
						"direction": "out",
							"id": function(input, state) {
								if (input && input.chdrnum)
									return "LA::Pru::Policy::" + input.chdrnum;
								return null;
							}
		}
	}

}