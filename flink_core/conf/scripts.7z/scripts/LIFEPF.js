{
    
    rels: {
        
        "LIFEPF_Customer": {
            "to": "Customer",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.lifcnum){
                    return "LA::Pru::Customer::" + input.lifcnum;
                }
                return null;
            }
        },
        //Arjun Changes
        "LIFEPF_Policy": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Policy::" + input.chdrnum;
                return null;
            }
        },
        "LIFEPF_Proposal": {
            "to": "Proposal",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.chdrnum)
                return "LA::Pru::Proposal::" + input.chdrnum;
                return null;
            }
        },

        "LIFEPF_LifeAssured": {
            "to": "LifeAssured",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.lifcnum){
                    return "LA::Pru::LifeAssured::" + input.lifcnum;
                }
                return null;
            }
        },
        
        "LIFEPF_Policy_FLUPPF": {
            "to": "Policy",
            "cardinality": "one",
            "direction": "out",
            "id":function(input,state){
                if(input && input.chdrnum && input.life){
                    return "LA::Pru::Policy::" + input.chdrnum +'_'+input.life;
                }
            }
        }

    }
}

