{

    targets: {

        "Hospital_Target" : {
            type: "Hospital"
        }
    },

    rels: {

        "ZHSDPF_Hospital" : {
            "to": "LifeAsia.ZHSDPF",
                "cardinality": "one",
                    "direction": "in"
        }
    }
}