{

	rels: {

	/*	"BABRPF_BankAccount": {
			"to": "LifeAsia.BABRPF",
				"cardinality": "one",
					"direction": "in",
						transform: function (input, output, state, operation) {
							if (input) {
								var customerBankInfo = {};
								customerBankInfo[input.bankkey] = input.bankdesc;
								output.Customer_BankAccount = customerBankInfo;
							}
							// when BABRPF comes after CLBAPF

							/*if (state.bankkey && state.clntnum) {
								var customerBankAccObj = {};
								var bankAccObj = {};
								bankAccObj.bankName = state.bankdesc;
								customerBankAccObj.clntnum = state.clntnum;
								customerBankAccObj.BankAcount = bankAccObj;
								output.Customer_BankAccount = customerBankAccObj;

							}
						}

		},

		"Customer_BankAccount" : {
            "to": "Customer",
                "cardinality": "many",
                    "direction": "in"
		},

		"CLBAPF_BankAccount": {
			"to": "LifeAsia.CLBAPF",
				"cardinality": "one",
					"direction": "in",
						transform: function (input, output, state, operation) {
							if (state.bankdesc && input.bankacckey) {
								input.bankAccounts[input.bankacckey.toLowerCase().replace(/ /g, "")].bankName
									= state.bankdesc;
							}

							//when CLBAPF comes first or modified , it sets the state to update 
							// the bank account object in Customer
							//print("inside CLBAPF_BankAccount state.bankkey :-" + state.bankkey);
							if (input.bankAccounts[input.bankacckey.toLowerCase().replace(/ /g, "")].bankCode) {
								state.bankkey = input.bankAccounts[input.bankacckey.toLowerCase().replace(/ /g, "")].bankCode;
								state.id = input.id;
							}
							if (input)
								delete input.bankacckey;
							output.BankAccount_Customer = input;
						}

		},

		"BankAccount_Customer": {
			"to": "Customer",
				"cardinality": "one",
					"direction": "out",
						"id": function (input, state) {
							if (input && input.id)
								return input.id;
							return null;
						}

		}*/
	}
}