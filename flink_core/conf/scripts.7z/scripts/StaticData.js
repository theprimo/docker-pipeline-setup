{
    targets: {
        
        "StaticData_Target": {
            type: "StaticData"
        }
    },
    
    rels: {
        
        "DESCPF_StaticData" : {
            "to": "LifeAsia.DESCPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        "BABRPF_StaticData": {
            "to": "LifeAsia.BABRPF",
            "cardinality": "one",
            "direction": "in"
        },
        
        // to hold the static data in a respective relation and it will get used when
        // relation gets created
        "StaticData_Payment" : {
            "to": "Payment",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_Claim" : {
            "to": "Claim",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_Customer" : {
            "to": "Customer",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_CustomerBankInfo" : {
            "to": "Customer",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_Proposal" : {
            "to": "Proposal",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_Agent" : {
            "to": "Agent",
            "cardinality": "many",
            "direction": "in"
        },
        
        "StaticData_Occupation" : {
            "to": "Customer",
            "cardinality": "many",
            "direction": "in"
        },
        "StaticData_FollowUp" : {
            "to": "FollowUp",
            "cardinality": "many",
            "direction": "in"
        }
    }
}