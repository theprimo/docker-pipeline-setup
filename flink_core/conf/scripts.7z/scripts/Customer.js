{
	
	targets: {
		
		"Customer_Target" : {
			type: "Customer"
		}
	},
	
	rels: {
		
		"CLBAPF_Customer" : {
			"to": "LifeAsia.CLBAPF",
			"cardinality": "one",
			"direction": "in"
			
		},
		
		"CLNTPF_Customer" : {
			"to": "LifeAsia.CLNTPF",
			"cardinality": "one",
			"direction": "in"
			
		},
		
		"StaticData_Occupation" : {
			"to": "StaticData",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && ((input.ctrycode && input.addrtype) || input.natlty)){
					return "LifeAsia::DESCPF::IT_T3644";
				}
				return null;
			}
		},
		
		"StaticData_Customer" : {
			"to": "StaticData",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && ((input.ctrycode && input.addrtype) || input.natlty)){
					return "LifeAsia::DESCPF::IT_T3645";
				}
				return null;
			}
		},
		
		"StaticData_CustomerBankInfo" : {
			"to": "StaticData",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.bankkey && input.bankacckey) {
					return  "LifeAsia::BABRPF::" + input.bankkey;
				}
				return null;
			}
		},
		
		"CHDRPF_Customer" : {
			"to": "LifeAsia.CHDRPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"Customer_BankAccount" : {
			"to": "BankAccount",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.bankkey)
				return "LA::Pru::BankAccount";
				return null;
			}
			
		},
		// clients field should be populated in the policy via Customer
		"Customer_Policy_clients" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.policyNo && input.cownnum)
				{
					var polNo = input.policyNo;
					delete input.policyNo;
					delete input.cownnum;
					return "LA::Pru::Policy::" + polNo;
				}
				return null;
			}
			
		},
		// beneficiaries field should be populated in the policy via Customer
		"Customer_Policy_beneficiaries" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.polno)
				return "LA::Pru::Policy::" + input.polno;
				return null;
			}
			
		},
		
		
		"BEXTPF_Customer" : {
			"to": "LifeAsia.BEXTPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"Customer_Policy" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.polno){
					return "LA::Pru::Policy::" + input.polno;
				}
				return null;
			}
		},
		
		"Claim_Customer" : {
			"to": "Claim",
			"cardinality": "many",
			"field": "claims",
			"direction": "in"
		},
		
		
		"BillingDetail_Customer" : {
			"to": "BillingDetail",
			"cardinality": "many",
			"field": "billing",
			"direction": "in"
		},
		
		"Policy_Customer" : {
			"to": "Policy",
			"cardinality": "many",
			"field": "policies",
			"direction": "in"
		},
		
		"Agent_Customer" : {
			"to": "Agent",
			"cardinality": "many",
			"field": "agent",
			"direction": "in"
		},
		
		"CLADPF_Customer" : {
			"to": "LifeAsia.CLADPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"CLDPPF_Customer" : {
			"to": "LifeAsia.CLDPPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"CLEXPF_Customer" : {
			"to": "LifeAsia.CLEXPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"LINSPF_Customer" : {
			"to": "LifeAsia.LINSPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"UWQSPF_Customer" : {
			"to": "LifeAsia.UWQSPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"LIFEPF_Customer" : {
			"to": "LifeAsia.LIFEPF",
			"cardinality": "one",
			"direction": "in"
		},
		// Life Assured field should be populated in the policy via Customer
		"Customer_Policy_lifeAssured" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.policyNo)
				return "LA::Pru::Policy::" + input.policyNo;
				return null;
			}
			
		},
		
		"REGPPF_Customer" : {
			"to": "LifeAsia.REGPPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"BNFYPF_Customer" : {
			"to": "LifeAsia.BNFYPF",
			"cardinality": "one",
			"direction": "in"
		},
		"CLRRPF_Customer":{
			"to": "LifeAsia.CLRRPF",
			"cardinality": "one",
			"direction": "in"
		},
		
		"Customer_Policy_Assignee" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.polno)
				{
					return "LA::Pru::Policy::" + input.polno;
				}
				return null;
			}
		},
		"Customer_Policy_Trustee" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.polno)
				{
					return "LA::Pru::Policy::" + input.polno;
				}
				return null;
			}
		},
		"Customer_Policy_Appointee" : {
			"to": "Policy",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.polno)
				{
					return "LA::Pru::Policy::" + input.polno;
				}
				return null;
			}
		},
		"AGNTPF_Customer" : {
            "to": "LifeAsia.AGNTPF",
            "cardinality": "many",
            "direction": "in"
        }
	}
}