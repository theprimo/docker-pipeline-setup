{
	
	targets: {
		
		"Agent_Target" : {
			type: "Agent"
		}
	},
	
	rels: {
		
		"AGLFPF_Agent" : {
			"to": "LifeAsia.AGLFPF",
			"cardinality": "one",
			"direction": "in",
			
		},
		
		"StaticData_Agent" : {
			"to": "StaticData",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.tsalesunt)
					return "LifeAsia::DESCPF::IT_TT518";
				return null;
			}
		},
		
		"AGNTPF_Agent" : {
			"to": "LifeAsia.AGNTPF",
			"cardinality": "one",
			"direction": "in",
			
		},
		
		"CHDRPF_Agent": {
			"to": "LifeAsia.CHDRPF",
			"cardinality": "one",
			"direction": "in",
			
		},
		
		// "Agent_ServicingAgents_Policy":{
		// 	"to": "Policy",
		// 	"cardinality": "one",
		// 	"direction": "out",
		// 	"id": function(input, state) {
		// 		if (input && input.policyNum)
		// 		return "LA::Pru::Policy::" + input.policyNum;
		// 		return null;
		// 	}
		// },

		"Agent_Customer" : {
			"to": "Customer",
			"cardinality": "one",
			"direction": "out",
			"id": function(input, state) {
				if (input && input.cownnum)
				return "LA::Pru::Customer::" + input.cownnum;
				return null;
			}
		},
		
		"ZHAGPF_Agent": {
			"to": "LifeAsia.ZHAGPF",
			"cardinality": "one",
			"direction": "in",
			
		},

		"ZAGDPF_Agent": {
			"to": "LifeAsia.ZAGDPF",
			"cardinality": "one",
			"direction": "in",
			
		},
		
		"Product_Agent" : {
			"to": "Product",
			"cardinality": "many",
			"field": "qualifyingProducts",
			"direction": "in"
		},

		"ZEDAPF_Agent": {
			"to": "LifeAsia.ZEDAPF",
				"cardinality": "one",
					"direction": "in",
						
		}
	}
}