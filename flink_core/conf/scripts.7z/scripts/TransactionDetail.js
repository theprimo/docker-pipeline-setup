{

	targets: {

		"TransactionDetail_Target" : {
			type: "TransactionDetail"
		}
	},

	rels: {

		"PTRNPF_TransactionDetail" : {
			"to": "LifeAsia.PTRNPF",
				"cardinality": "one",
					"direction": "in"
		},

		"ACMVPF_TransactionDetail" : {
			"to": "LifeAsia.ACMVPF",
				"cardinality": "one",
					"direction": "in"
		}
	}
}