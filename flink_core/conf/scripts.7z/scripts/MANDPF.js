{
  
  rels: {
    "MANDPF_BillingDetail" : {
      "to": "BillingDetail",
        "cardinality": "one",
          "direction": "out",
            "id": function(input, state) {
              if (input && (input.payrnum || input.mandref))
                return "LA::Pru::BillingDetail::" + input.payrnum + "_" + input.mandref;
              return null;
            }
    }
  }
}