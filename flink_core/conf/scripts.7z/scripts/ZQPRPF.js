{
   
    rels: {

        "ZQPRPF_Product": {
            "to": "Product",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.cnttype){                                
                                return "LA::Pru::Product" + "::" + input.cnttype;
                            }                                
                            return null;
                        }
        }
           
    }
}