{
    
    rels: {

        "CLMDPF_Claim": {
            "to": "Claim",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.chdrnum && input.life && input.tranno)
                                return "LA::Pru::Claim::" + input.chdrnum + "_" + input.life + "_" + input.tranno
                            return null;
                        }
        }
    }
}