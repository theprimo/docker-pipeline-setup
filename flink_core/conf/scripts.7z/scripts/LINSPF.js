{
        
    rels: {
        "LINSPF_Customer": {
            "to": "Customer",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if(input && input.chdrnum)
                                return "LA::Pru::Customer::"+input.chdrnum;
                            return null;
                        }

        }
    }
}

