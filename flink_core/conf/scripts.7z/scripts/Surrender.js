{

    targets: {

        "Surrender_Target" : {
            type: "Surrender"
        }
    },

    rels: {

        "SURDPF_Surrender" : {
            "to": "LifeAsia.SURDPF",
                "cardinality": "one",
                    "direction": "in"
        },

        "Surrender_Policy" : {
            "to": "Policy",
                "cardinality": "one",
                    "direction": "out",
                        "id": function (input, state) {
                            if (input && input.policy)
                                return "LA::Pru::Policy::" + input.policy;
                            return null;
                        }
        }
    }
}