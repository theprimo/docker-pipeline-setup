{
       
    rels: {
        
        "ITEMPF_Product": {
            "to": "Product",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.validflag && input.validflag == "1" && input.itemitem && input.itemtabl && ((input.itemtabl.toUpperCase() == "T5688" && input.itemcoy && input.itemcoy == "2") || input.itemtabl.toUpperCase() == "T5673"))
                    return "LA::Pru::Product::" + input.itemitem;
                return null;
            }
        },
        
        "ITEMPF_ProductComponent": {
            "to": "ProductComponent",
            "cardinality": "one",
            "direction": "out",
            "id": function (input, state) {
                if (input && input.validflag && input.validflag == "1" && input.itemitem && input.itemtabl && input.itemtabl.toUpperCase() == "T5687")
                    return "LA::Pru::ProductComponent::" + input.itemitem;
                return null;
            }
        }
    }
}