{
 
  rels: {

    "ACMVPF_TransactionDetail": {
      "to": "TransactionDetail",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.rldgacct && input.batctrcde && input.tranno)
                return "LA::Pru::TransactionDetail::" + input.rldgacct.slice(0, 8) + "_" + input.batctrcde + "_" + input.tranno;
              return null;
            }
    },

    "ACMVPF_RegularClaimSettlementDate": {
      "to": "Claim",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.sacscode == 'lp' && input.sacstyp == 'rs' && input.batctrcde == 'b206' && input.trandesc && input.trandesc.slice(14, 18) != "0000")
                return "LA::Pru::Claim::" + input.trandesc.slice(0, 8) + "_" + input.trandesc.slice(8, 10) + "_" + input.trandesc.slice(10, 12) + "_" + input.trandesc.slice(12, 14) + "_" + input.trandesc.slice(14, 18);
              return null;
            }
    },
    //using only chdrnum+life+0000 to find the death claim
    "ACMVPF_DeathClaimSettlementDate": {
      "to": "Claim",
        "cardinality": "one",
          "direction": "out",
            "id": function (input, state) {
              if (input && input.sacscode == 'lp' && input.sacstyp == 'rs' && input.batctrcde == 'b206' && input.trandesc && input.trandesc.slice(14, 18) == "0000")
                return "LA::Pru::Claim::" + input.trandesc.slice(0, 8) + "_" + input.trandesc.slice(8, 10) + "_0000";
              return null;
            }
    }
  }
}